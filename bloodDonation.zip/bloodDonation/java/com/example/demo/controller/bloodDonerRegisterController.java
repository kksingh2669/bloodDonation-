package com.example.demo.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.model.BloodDonerLogin;
import com.example.demo.model.BloodDonerRegister;
import com.example.demo.repository.bloodDonerRegisterRepository;

@Controller
public class bloodDonerRegisterController {
	
	@Autowired
	bloodDonerRegisterRepository bdrr;
	
	@Autowired
	BloodDonerRegister bdr;
	
	@RequestMapping("register")
	public ModelAndView DonerRegister() {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("donerRegister");
		mv.addObject("bloodDonerRegister",new BloodDonerRegister());
		return mv;
	}

	@RequestMapping("registerProcess")
	public ModelAndView addDoner(@Valid @ModelAttribute("bloodDonerRegister") BloodDonerRegister bdr,BindingResult bindingResult) {
		ModelAndView mv = new ModelAndView();
		BloodDonerRegister userExists = bdrr.findByuserid(bdr.getUserid());
	    if (userExists != null) {
	        bindingResult
	                .rejectValue("email", "error.user",
	                        "There is already a user registered with the username provided");
	    }
	    if (bindingResult.hasErrors()) {
	        mv.setViewName("donerRegister");
	        mv.addObject("message","Something went wrong! You are not able to register");
	        mv.addObject("bloodDonerRegister",bdr);
	       System.out.println(bindingResult);
	    } else {
	        bdrr.save(bdr);
	        mv.setViewName("donerLogin");
	        mv.addObject("message", "User has been registered successfully");
	        mv.addObject("bloodDonerRegister", bdr);
	    }
	    return mv;
	}
	

}
