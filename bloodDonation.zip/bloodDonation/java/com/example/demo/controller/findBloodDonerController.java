package com.example.demo.controller;


import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.BasicQuery;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.model.BloodDonerRegister;
import com.example.demo.model.FindBloodDoner;
import com.example.demo.model.FindBloodResult;
import com.example.demo.repository.bloodDonerRegisterRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
//import com.example.demo.service.BloodDonerService;

@RestController
@RequestMapping(value = "/")
public class findBloodDonerController {
	
	@Autowired
	FindBloodDoner fbd;
	
	@Autowired
	BloodDonerRegister bdr;
	
	@Autowired
	bloodDonerRegisterRepository bdrr;
	
	
	@Autowired
	MongoTemplate mongoTemplate;
	
	@RequestMapping("findDoner")
	public ModelAndView findDoner() {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("findBloodDoner");
		mv.addObject("findBloodDoner",fbd);
		return mv;
	}
	
	@RequestMapping("findBloodDonerProcess")
	public ModelAndView findB(HttpServletRequest req){
		ModelAndView mv=new ModelAndView();
		Query query = new Query();
		query.fields().include("fullname");
		query.fields().include("mobilenumber");
		query.fields().include("availability");
		query.fields().include("bloodgroup");
		
		query.addCriteria(
		    new Criteria().andOperator(
		    		Criteria.where("bloodgroup").is(req.getParameter("bloodgroup")),
		    		Criteria.where("city").is(req.getParameter("city"))
		    )
		);

		List<FindBloodResult> users = mongoTemplate.find(query, FindBloodResult.class);
		mv.setViewName("findBloodResult");
		mv.addObject("users1", users);
		return mv;
	}
}

