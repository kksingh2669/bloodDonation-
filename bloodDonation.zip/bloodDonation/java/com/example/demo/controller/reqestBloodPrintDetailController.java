package com.example.demo.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.model.RequestBloodPrint;
import com.example.demo.model.RequestBloodPrintDetail;
import com.example.demo.repository.requestBloodRepository;

@Controller
public class reqestBloodPrintDetailController {
	@Autowired
	requestBloodRepository rbr;

	@Autowired
	RequestBloodPrintDetail rbpd;

	@Autowired
	MongoTemplate mongoTemplate;

	@RequestMapping("redirect1")
	public ModelAndView reqBloodRes1(HttpServletRequest req,@RequestParam("name") String s1,@RequestParam("name1") String s2) {
		ModelAndView mv = new ModelAndView();
		Query query = new Query();
		query.fields().include("patientname");
		query.fields().include("hospitalandaddress");
		query.fields().include("doctorname");
		query.fields().include("whenrequired");
		query.fields().include("contactname");
		query.fields().include("contactnumber");
		query.fields().include("bloodgroup");

		
		  query.addCriteria( new Criteria().andOperator(
		  Criteria.where("patientname").is(s1),
		  Criteria.where("whenrequired").is(s2) )
		  ); 
		  
		 
		  
		 
		List<RequestBloodPrintDetail> request3 = mongoTemplate.find(query, RequestBloodPrintDetail.class);
		mv.setViewName("reqBloodPrintDetail");
		mv.addObject("request4", request3);
		return mv;
	}

}
