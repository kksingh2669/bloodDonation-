package com.example.demo.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.model.RequestBlood;
import com.example.demo.repository.requestBloodRepository;

@Controller
public class requestBloodController {

	@Autowired
	requestBloodRepository rbr;
	
	@Autowired
	RequestBlood rb;
	
	@RequestMapping("request")
	public ModelAndView requestRegister() {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("reqBlood");
		mv.addObject("requestBlood",new RequestBlood());
		return mv;
	}
	
	@RequestMapping("requestBloodProcess")
	public ModelAndView addDoner(@Valid @ModelAttribute("requestBlood") RequestBlood rb,BindingResult bindingResult) {
		ModelAndView mv = new ModelAndView();
		RequestBlood userExists = rbr.findBydoctorname(rb.getDoctorname());
	    if (userExists != null) {
	        bindingResult
	                .rejectValue("email", "error.user",
	                        "You have already rwquested with the username provided");
	    }
	    if (bindingResult.hasErrors()) {
	        mv.setViewName("reqBlood");
	        mv.addObject("message","Something went wrong! You are not able to request");
	        mv.addObject("requestBlood",rb);
	        System.out.println(bindingResult);
	    } else {
	        rbr.save(rb);
	        mv.setViewName("reqBlood");
	        mv.addObject("message", "User has been requested successfully");
	        mv.addObject("requestBlood",rb);
	    }
	    return mv;
	}
}
