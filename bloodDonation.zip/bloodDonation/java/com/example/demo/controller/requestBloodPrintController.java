package com.example.demo.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.model.FindBloodResult;
import com.example.demo.model.RequestBlood;
import com.example.demo.model.RequestBloodPrint;
import com.example.demo.model.RequestBloodPrintDetail;
import com.example.demo.repository.requestBloodRepository;

@Controller
public class requestBloodPrintController {
	@Autowired
	requestBloodRepository rbr;
	
	@Autowired
	RequestBloodPrint rbp;
	
	@Autowired
	MongoTemplate mongoTemplate;
	
	@RequestMapping("redirect")
	public ModelAndView reqBloodRes(HttpServletRequest req){
		ModelAndView mv=new ModelAndView();
		Query query = new Query();
		query.fields().include("patientname");
		query.fields().include("whenrequired");
	
		List<RequestBloodPrint> request1 = mongoTemplate.find(query, RequestBloodPrint.class);
		mv.setViewName("reqBloodPrint");
		mv.addObject("request2", request1);
		return mv;
	}
	
	

}
