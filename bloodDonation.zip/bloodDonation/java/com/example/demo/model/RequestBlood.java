package com.example.demo.model;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.stereotype.Component;

@Component
@Document(collection="RequestBlood")
public class RequestBlood {
	private String patientname;
	private String bloodgroup;
	private String city;
	private String hospitalandaddress;
	private String doctorname;
	private String contactname;
	private String contactemail;
	private String contactnumber;
	private String whenrequired;
	private String othermessage;
	
	public String getPatientname() {
		return patientname;
	}
	public void setPatientname(String patientname) {
		this.patientname = patientname;
	}
	public String getBloodgroup() {
		return bloodgroup;
	}
	public void setBloodgroup(String bloodgroup) {
		this.bloodgroup = bloodgroup;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getHospitalandaddress() {
		return hospitalandaddress;
	}
	public void setHospitalandaddress(String hospitalandaddress) {
		this.hospitalandaddress = hospitalandaddress;
	}
	public String getDoctorname() {
		return doctorname;
	}
	public void setDoctorname(String doctorname) {
		this.doctorname = doctorname;
	}
	public String getContactname() {
		return contactname;
	}
	public void setContactname(String contactname) {
		this.contactname = contactname;
	}
	public String getContactemail() {
		return contactemail;
	}
	public void setContactemail(String contactemail) {
		this.contactemail = contactemail;
	}
	public String getContactnumber() {
		return contactnumber;
	}
	public void setContactnumber(String contactnumber) {
		this.contactnumber = contactnumber;
	}
	public String getWhenrequired() {
		return whenrequired;
	}
	public void setWhenrequired(String whenrequired) {
		this.whenrequired = whenrequired;
	}
	public String getOthermessage() {
		return othermessage;
	}
	public void setOthermessage(String othermessage) {
		this.othermessage = othermessage;
	}
	

}
