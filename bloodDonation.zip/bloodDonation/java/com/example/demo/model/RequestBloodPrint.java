package com.example.demo.model;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.stereotype.Component;

@Component
@Document(collection="RequestBlood")
public class RequestBloodPrint {
	private String patientname;
	private String whenrequired;
	public String getPatientname() {
		return patientname;
	}
	public void setPatientname(String patientname) {
		this.patientname = patientname;
	}
	public String getWhenrequired() {
		return whenrequired;
	}
	public void setWhenrequired(String whenrequired) {
		this.whenrequired = whenrequired;
	}
	

}
