package com.example.demo.model;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.stereotype.Component;

@Component
@Document(collection="RequestBlood")
public class RequestBloodPrintDetail {
	private String patientname;
	private String hospitalandaddress;
	private String doctorname;
	private String whenrequired;
	private String contactname;
	private String contactnumber;
	private String bloodgroup;
	public String getPatientname() {
		return patientname;
	}
	public void setPatientname(String patientname) {
		this.patientname = patientname;
	}
	public String getHospitalandaddress() {
		return hospitalandaddress;
	}
	public void setHospitalandaddress(String hospitalandaddress) {
		this.hospitalandaddress = hospitalandaddress;
	}
	public String getDoctorname() {
		return doctorname;
	}
	public void setDoctorname(String doctorname) {
		this.doctorname = doctorname;
	}
	public String getWhenrequired() {
		return whenrequired;
	}
	public void setWhenrequired(String whenrequired) {
		this.whenrequired = whenrequired;
	}
	public String getContactname() {
		return contactname;
	}
	public void setContactname(String contactname) {
		this.contactname = contactname;
	}
	public String getContactnumber() {
		return contactnumber;
	}
	public void setContactnumber(String contactnumber) {
		this.contactnumber = contactnumber;
	}
	public String getBloodgroup() {
		return bloodgroup;
	}
	public void setBloodgroup(String bloodgroup) {
		this.bloodgroup = bloodgroup;
	}
	
}
