package com.example.demo.repository;


import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.example.demo.model.BloodDonerRegister;
import com.example.demo.model.RequestBlood;
import com.mongodb.DBCollection;

public interface bloodDonerRegisterRepository extends MongoRepository<BloodDonerRegister, String> {
	BloodDonerRegister findByuserid(String string);

	BloodDonerRegister findBybloodgroup(String string);

	BloodDonerRegister findBycity(String city);

}
