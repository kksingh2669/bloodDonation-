package com.example.demo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.demo.model.RequestBlood;

public interface requestBloodRepository extends MongoRepository<RequestBlood, String> {
	RequestBlood findBydoctorname(String doctorname);
}
